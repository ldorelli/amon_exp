from distutils.core import setup

setup(name='Amon Analytics',
	version='1.0',
	description='ToolsTo Analyze Social and Complex Network Data',
	author='Luis Fernando Dorelli de Abreu',
	author_email='lfdorelli@gmail.com',
	py_modules=['amon_analytics'],
)
